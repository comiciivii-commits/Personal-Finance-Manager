"""SQLite connection, schema, demo data, and finance queries."""

from __future__ import annotations

from datetime import date
import sqlite3
from pathlib import Path
from typing import Any

import jdatetime
from flask import current_app, g

from dates import jalali_month_label, month_bounds, persian_digits, shift_jalali_month, to_jalali


INCOME_CATEGORIES = ("حقوق", "پروژهٔ آزاد", "سرمایه‌گذاری", "هدیه", "سایر درآمدها")
EXPENSE_CATEGORIES = (
    "خوراک", "حمل‌ونقل", "مسکن", "قبوض", "درمان",
    "خرید", "تفریح", "آموزش", "سایر هزینه‌ها",
)


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        connection = sqlite3.connect(current_app.config["DATABASE"], timeout=15)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 15000")
        g.db = connection
    return g.db


def close_db(_error: BaseException | None = None) -> None:
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()


def initialize_database(app) -> None:
    database_path = Path(app.config["DATABASE"])
    database_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database_path, timeout=15)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL COLLATE NOCASE,
                kind TEXT NOT NULL CHECK (kind IN ('income', 'expense')),
                UNIQUE (name, kind)
            );
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL CHECK (kind IN ('income', 'expense')),
                amount INTEGER NOT NULL CHECK (amount > 0),
                transaction_date TEXT NOT NULL,
                category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
                description TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions(transaction_date);
            CREATE INDEX IF NOT EXISTS idx_transactions_category ON transactions(category_id);
            CREATE TABLE IF NOT EXISTS budgets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
                category_id INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
                amount INTEGER NOT NULL CHECK (amount > 0),
                UNIQUE (year, month, category_id)
            );
            """
        )
        for name in INCOME_CATEGORIES:
            connection.execute(
                "INSERT OR IGNORE INTO categories (name, kind) VALUES (?, 'income')", (name,)
            )
        for name in EXPENSE_CATEGORIES:
            connection.execute(
                "INSERT OR IGNORE INTO categories (name, kind) VALUES (?, 'expense')", (name,)
            )
        if app.config.get("SEED_DEMO_DATA", True):
            _seed_demo_data(connection)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def _seed_demo_data(connection: sqlite3.Connection) -> None:
    if connection.execute("SELECT COUNT(*) FROM transactions").fetchone()[0]:
        return
    categories = {
        row["name"]: row["id"]
        for row in connection.execute("SELECT id, name FROM categories").fetchall()
    }
    today = jdatetime.date.today()
    samples = []
    for offset in range(-4, 1):
        year, month = shift_jalali_month(today.year, today.month, offset)
        # Constructing a date lets jdatetime validate each month without extra dependencies.
        day_one = jdatetime.date(year, month, 1).togregorian()
        next_year, next_month = shift_jalali_month(year, month, 1)
        month_length = (jdatetime.date(next_year, next_month, 1).togregorian() - day_one).days
        day_a = min(1 if offset == 0 else 6, month_length)
        day_b = min(3 if offset == 0 else 15, month_length)
        day_c = min(5 if offset == 0 else 22, month_length)
        samples.extend(
            [
                ("income", 52_000_000 + (offset % 3) * 2_000_000, year, month, day_a,
                 categories["حقوق"], "حقوق ماهانه"),
                ("expense", 4_200_000, year, month, day_b,
                 categories["خوراک"], "خرید هفتگی"),
                ("expense", 1_650_000, year, month, day_c,
                 categories["حمل‌ونقل"], "رفت‌وآمد ماه"),
                ("expense", 6_800_000, year, month, min(day_b + 2, month_length),
                 categories["مسکن"], "سهم هزینهٔ خانه"),
            ]
        )
    for kind, amount, year, month, day, category_id, description in samples:
        transaction_date = jdatetime.date(year, month, day).togregorian().isoformat()
        connection.execute(
            """
            INSERT INTO transactions (kind, amount, transaction_date, category_id, description)
            VALUES (?, ?, ?, ?, ?)
            """,
            (kind, amount, transaction_date, category_id, description),
        )

    for category_name, amount in (
        ("خوراک", 12_000_000),
        ("حمل‌ونقل", 5_000_000),
        ("مسکن", 18_000_000),
    ):
        connection.execute(
            "INSERT OR IGNORE INTO budgets (year, month, category_id, amount) VALUES (?, ?, ?, ?)",
            (today.year, today.month, categories[category_name], amount),
        )


def list_categories(kind: str | None = None) -> list[dict[str, Any]]:
    if kind:
        rows = get_db().execute(
            "SELECT id, name, kind FROM categories WHERE kind = ? ORDER BY name", (kind,)
        ).fetchall()
    else:
        rows = get_db().execute(
            "SELECT id, name, kind FROM categories ORDER BY kind, name"
        ).fetchall()
    return [dict(row) for row in rows]


def add_category(name: str, kind: str) -> int:
    name = name.strip()
    if not name or len(name) > 40:
        raise ValueError("نام دسته‌بندی باید بین ۱ تا ۴۰ نویسه باشد.")
    if kind not in ("income", "expense"):
        raise ValueError("نوع دسته‌بندی معتبر نیست.")
    try:
        cursor = get_db().execute(
            "INSERT INTO categories (name, kind) VALUES (?, ?)", (name, kind)
        )
        get_db().commit()
        return int(cursor.lastrowid)
    except sqlite3.IntegrityError as exc:
        get_db().rollback()
        raise ValueError("این دسته‌بندی از قبل وجود دارد.") from exc


def update_category(category_id: int, name: str) -> None:
    name = name.strip()
    if not name or len(name) > 40:
        raise ValueError("نام دسته‌بندی باید بین ۱ تا ۴۰ نویسه باشد.")
    try:
        cursor = get_db().execute(
            "UPDATE categories SET name = ? WHERE id = ?", (name, category_id)
        )
        if not cursor.rowcount:
            raise ValueError("دسته‌بندی پیدا نشد.")
        get_db().commit()
    except sqlite3.IntegrityError as exc:
        get_db().rollback()
        raise ValueError("دسته‌بندی دیگری با این نام در همین گروه وجود دارد.") from exc


def delete_category(category_id: int) -> None:
    try:
        cursor = get_db().execute("DELETE FROM categories WHERE id = ?", (category_id,))
        if not cursor.rowcount:
            raise ValueError("دسته‌بندی پیدا نشد.")
        get_db().commit()
    except sqlite3.IntegrityError as exc:
        get_db().rollback()
        raise ValueError("این دسته‌بندی به تراکنش یا بودجه متصل است و حذف نمی‌شود.") from exc


def _validate_category(category_id: int, kind: str) -> None:
    row = get_db().execute(
        "SELECT kind FROM categories WHERE id = ?", (category_id,)
    ).fetchone()
    if row is None:
        raise ValueError("دسته‌بندی انتخاب‌شده پیدا نشد.")
    if row["kind"] != kind:
        raise ValueError("دسته‌بندی باید با نوع تراکنش هم‌خوانی داشته باشد.")


def add_transaction(
    kind: str, amount: int, transaction_date: date, category_id: int, description: str
) -> int:
    _validate_transaction(kind, amount, description)
    _validate_category(category_id, kind)
    cursor = get_db().execute(
        """
        INSERT INTO transactions (kind, amount, transaction_date, category_id, description)
        VALUES (?, ?, ?, ?, ?)
        """,
        (kind, amount, transaction_date.isoformat(), category_id, description.strip()),
    )
    get_db().commit()
    return int(cursor.lastrowid)


def update_transaction(
    transaction_id: int, kind: str, amount: int, transaction_date: date,
    category_id: int, description: str,
) -> None:
    _validate_transaction(kind, amount, description)
    _validate_category(category_id, kind)
    cursor = get_db().execute(
        """
        UPDATE transactions SET kind = ?, amount = ?, transaction_date = ?,
            category_id = ?, description = ? WHERE id = ?
        """,
        (kind, amount, transaction_date.isoformat(), category_id, description.strip(), transaction_id),
    )
    if not cursor.rowcount:
        raise ValueError("تراکنش پیدا نشد.")
    get_db().commit()


def _validate_transaction(kind: str, amount: int, description: str) -> None:
    if kind not in ("income", "expense"):
        raise ValueError("نوع تراکنش معتبر نیست.")
    if not isinstance(amount, int) or amount <= 0:
        raise ValueError("مبلغ باید عدد صحیح و بیشتر از صفر باشد.")
    if len(description.strip()) > 240:
        raise ValueError("توضیحات نباید بیشتر از ۲۴۰ نویسه باشد.")


def delete_transaction(transaction_id: int) -> None:
    cursor = get_db().execute("DELETE FROM transactions WHERE id = ?", (transaction_id,))
    if not cursor.rowcount:
        raise ValueError("تراکنش پیدا نشد.")
    get_db().commit()


def list_transactions(
    start_date: str | None = None,
    end_date: str | None = None,
    kind: str | None = None,
    category_id: int | None = None,
    search: str | None = None,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    clauses: list[str] = []
    parameters: list[Any] = []
    if start_date:
        clauses.append("t.transaction_date >= ?")
        parameters.append(start_date)
    if end_date:
        clauses.append("t.transaction_date <= ?")
        parameters.append(end_date)
    if kind in ("income", "expense"):
        clauses.append("t.kind = ?")
        parameters.append(kind)
    if category_id:
        clauses.append("t.category_id = ?")
        parameters.append(category_id)
    if search:
        clauses.append("(t.description LIKE ? OR c.name LIKE ?)")
        parameters.extend((f"%{search.strip()}%", f"%{search.strip()}%"))
    query = """
        SELECT t.id, t.kind, t.amount, t.transaction_date, t.category_id,
               c.name AS category_name, t.description
        FROM transactions t JOIN categories c ON c.id = t.category_id
    """
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " ORDER BY t.transaction_date DESC, t.id DESC"
    if limit:
        query += " LIMIT ?"
        parameters.append(limit)
    rows = get_db().execute(query, parameters).fetchall()
    result = [dict(row) for row in rows]
    for row in result:
        row["jalali_date"] = to_jalali(date.fromisoformat(row["transaction_date"]))
    return result


def get_totals(start: date | None = None, end_exclusive: date | None = None) -> dict[str, int]:
    clauses: list[str] = []
    parameters: list[str] = []
    if start:
        clauses.append("transaction_date >= ?")
        parameters.append(start.isoformat())
    if end_exclusive:
        clauses.append("transaction_date < ?")
        parameters.append(end_exclusive.isoformat())
    query = "SELECT kind, COALESCE(SUM(amount), 0) AS total FROM transactions"
    if clauses:
        query += " WHERE " + " AND ".join(clauses)
    query += " GROUP BY kind"
    rows = get_db().execute(query, parameters).fetchall()
    totals = {"income": 0, "expense": 0}
    for row in rows:
        totals[row["kind"]] = int(row["total"])
    totals["balance"] = totals["income"] - totals["expense"]
    return totals


def get_month_summary(year: int, month: int) -> dict[str, int | str]:
    start, end = month_bounds(year, month)
    totals = get_totals(start, end)
    return {
        "year": year,
        "month": month,
        "label": jalali_month_label(year, month),
        **totals,
    }


def get_daily_report(year: int, month: int) -> list[dict[str, int | str]]:
    start, end = month_bounds(year, month)
    rows = get_db().execute(
        """
        SELECT transaction_date, kind, SUM(amount) AS total
        FROM transactions WHERE transaction_date >= ? AND transaction_date < ?
        GROUP BY transaction_date, kind
        """,
        (start.isoformat(), end.isoformat()),
    ).fetchall()
    values: dict[str, dict[str, int]] = {}
    for row in rows:
        values.setdefault(row["transaction_date"], {"income": 0, "expense": 0})
        values[row["transaction_date"]][row["kind"]] = int(row["total"])
    from dates import iter_days, persian_digits

    result = []
    for current in iter_days(start, end):
        day_values = values.get(current.isoformat(), {"income": 0, "expense": 0})
        jalali_day = jdatetime.date.fromgregorian(date=current).day
        result.append(
            {
                "label": persian_digits(jalali_day),
                "date": current.isoformat(),
                "income": day_values["income"],
                "expense": day_values["expense"],
                "balance": day_values["income"] - day_values["expense"],
            }
        )
    return result


def get_monthly_report(year: int) -> list[dict[str, int | str]]:
    return [get_month_summary(year, month) for month in range(1, 13)]


def get_yearly_report(year: int, years: int = 5) -> list[dict[str, int | str]]:
    if years < 1:
        raise ValueError("تعداد سال‌های گزارش باید بیشتر از صفر باشد.")
    result = []
    for report_year in range(year - years + 1, year + 1):
        start = month_bounds(report_year, 1)[0]
        end = month_bounds(report_year + 1, 1)[0]
        totals = get_totals(start, end)
        result.append({"year": report_year, "label": persian_digits(report_year), **totals})
    return result


def get_expense_breakdown(start: date, end_exclusive: date) -> list[dict[str, Any]]:
    rows = get_db().execute(
        """
        SELECT c.id AS category_id, c.name AS category_name, SUM(t.amount) AS total
        FROM transactions t JOIN categories c ON c.id = t.category_id
        WHERE t.kind = 'expense' AND t.transaction_date >= ? AND t.transaction_date < ?
        GROUP BY c.id, c.name ORDER BY total DESC
        """,
        (start.isoformat(), end_exclusive.isoformat()),
    ).fetchall()
    return [dict(row) for row in rows]


def upsert_budget(year: int, month: int, category_id: int, amount: int) -> None:
    if not isinstance(amount, int) or amount <= 0:
        raise ValueError("بودجه باید عدد صحیح و بیشتر از صفر باشد.")
    _validate_category(category_id, "expense")
    get_db().execute(
        """
        INSERT INTO budgets (year, month, category_id, amount)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(year, month, category_id) DO UPDATE SET amount = excluded.amount
        """,
        (year, month, category_id, amount),
    )
    get_db().commit()


def list_budgets(year: int, month: int) -> list[dict[str, Any]]:
    start, end = month_bounds(year, month)
    rows = get_db().execute(
        """
        SELECT b.id, b.year, b.month, b.category_id, b.amount AS budget_amount,
               c.name AS category_name,
               COALESCE(SUM(t.amount), 0) AS used_amount
        FROM budgets b JOIN categories c ON c.id = b.category_id
        LEFT JOIN transactions t ON t.category_id = b.category_id
            AND t.kind = 'expense' AND t.transaction_date >= ? AND t.transaction_date < ?
        WHERE b.year = ? AND b.month = ?
        GROUP BY b.id, b.year, b.month, b.category_id, b.amount, c.name
        ORDER BY c.name
        """,
        (start.isoformat(), end.isoformat(), year, month),
    ).fetchall()
    budgets = [dict(row) for row in rows]
    for budget in budgets:
        budget["remaining_amount"] = budget["budget_amount"] - budget["used_amount"]
        budget["ratio"] = budget["used_amount"] / budget["budget_amount"]
    return budgets


def delete_budget(budget_id: int) -> None:
    cursor = get_db().execute("DELETE FROM budgets WHERE id = ?", (budget_id,))
    if not cursor.rowcount:
        raise ValueError("بودجه پیدا نشد.")
    get_db().commit()
