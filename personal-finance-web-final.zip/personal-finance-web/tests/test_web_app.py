from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

from app import create_app
import db as finance_db
from dates import jalali_today, month_bounds


class PersonalFinanceWebTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.database_path = Path(self.temp_dir.name) / "finance.sqlite3"
        self.app = create_app(
            {
                "TESTING": True,
                "DATABASE": str(self.database_path),
                "SEED_DEMO_DATA": False,
                "SECRET_KEY": "test-only",
            }
        )
        self.client = self.app.test_client()
        with self.app.app_context():
            self.income_category = next(
                item["id"] for item in finance_db.list_categories("income")
                if item["name"] == "حقوق"
            )
            self.food_category = next(
                item["id"] for item in finance_db.list_categories("expense")
                if item["name"] == "خوراک"
            )
            self.transport_category = next(
                item["id"] for item in finance_db.list_categories("expense")
                if item["name"] == "حمل‌ونقل"
            )

    def tearDown(self):
        self.temp_dir.cleanup()

    def add_transaction(self, kind, amount, jalali_date, category_id, description):
        return self.client.post(
            "/transactions",
            data={
                "kind": kind,
                "amount": str(amount),
                "transaction_date": jalali_date,
                "category_id": str(category_id),
                "description": description,
            },
            follow_redirects=True,
        )

    def test_dashboard_renders_persian_rtl_and_sample_charts(self):
        response = self.client.get("/")
        body = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn('lang="fa" dir="rtl"', body)
        self.assertIn("نمودار مقایسه درآمد و هزینه", body)
        self.assertIn("خلاصهٔ", body)

    def test_transaction_create_edit_delete_and_persistence(self):
        self.add_transaction("income", "۱٬۰۰۰٬۰۰۰", "۱۴۰۳/۰۱/۰۱",
                             self.income_category, "حقوق فروردین")
        with self.app.app_context():
            transaction = finance_db.list_transactions()[0]
            self.assertEqual(transaction["amount"], 1_000_000)
            transaction_id = transaction["id"]
            self.assertEqual(transaction["description"], "حقوق فروردین")

        response = self.client.post(
            f"/transactions/{transaction_id}/edit",
            data={
                "kind": "expense",
                "amount": "۳۰۰٬۰۰۰",
                "transaction_date": "۱۴۰۳/۰۱/۰۲",
                "category_id": str(self.food_category),
                "description": "خرید نان",
            },
            follow_redirects=True,
        )
        self.assertIn("تراکنش ویرایش شد", response.get_data(as_text=True))
        with self.app.app_context():
            updated = finance_db.list_transactions()[0]
            self.assertEqual(updated["kind"], "expense")
            self.assertEqual(updated["amount"], 300_000)
            self.assertEqual(updated["category_name"], "خوراک")

        response = self.client.post(
            f"/transactions/{transaction_id}/delete", follow_redirects=True
        )
        self.assertIn("تراکنش حذف شد", response.get_data(as_text=True))
        with self.app.app_context():
            self.assertEqual(finance_db.list_transactions(), [])

        self.add_transaction("income", "۵۰۰۰۰۰", "۱۴۰۳/۰۱/۰۳",
                             self.income_category, "درآمد برای آزمون ماندگاری")
        reopened = create_app(
            {"TESTING": True, "DATABASE": str(self.database_path), "SEED_DEMO_DATA": False}
        )
        with reopened.app_context():
            persisted = finance_db.list_transactions()
            self.assertEqual(len(persisted), 1)
            self.assertEqual(persisted[0]["amount"], 500_000)
            self.assertEqual(persisted[0]["description"], "درآمد برای آزمون ماندگاری")

    def test_invalid_transaction_is_rejected_with_persian_message(self):
        response = self.add_transaction(
            "expense", "۰", "۱۴۰۳/۰۱/۰۱", self.food_category, "مبلغ نامعتبر"
        )
        body = response.get_data(as_text=True)
        self.assertIn("باید بیشتر از صفر باشد", body)
        with self.app.app_context():
            self.assertEqual(finance_db.list_transactions(), [])

    def test_date_category_and_kind_filters(self):
        self.add_transaction("expense", "۲۰۰۰۰", "۱۴۰۳/۰۱/۰۱", self.food_category, "نان روزانه")
        self.add_transaction("expense", "۴۰۰۰۰", "۱۴۰۳/۰۱/۰۲", self.transport_category, "کرایه")
        self.add_transaction("income", "۹۰۰۰۰", "۱۴۰۳/۰۱/۰۳", self.income_category, "درآمد پروژه")
        response = self.client.get(
            f"/transactions?from=۱۴۰۳/۰۱/۰۱&to=۱۴۰۳/۰۱/۰۲&kind=expense&category={self.food_category}&q=نان"
        )
        body = response.get_data(as_text=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn("نان روزانه", body)
        self.assertNotIn("درآمد پروژه", body)
        self.assertNotIn("کرایه", body)

    def test_budgets_warn_when_near_limit_and_can_be_updated(self):
        self.client.post(
            "/budgets",
            data={"year": "۱۴۰۳", "month": "۰۱", "category_id": str(self.food_category), "amount": "۱۰۰۰۰۰"},
            follow_redirects=True,
        )
        self.add_transaction("expense", "۸۵۰۰۰", "۱۴۰۳/۰۱/۰۵", self.food_category, "خرید")
        response = self.client.get("/budgets?year=۱۴۰۳&month=۰۱")
        self.assertIn("به سقف بودجه نزدیک شده‌اید", response.get_data(as_text=True))
        with self.app.app_context():
            budgets = finance_db.list_budgets(1403, 1)
            self.assertEqual(budgets[0]["remaining_amount"], 15_000)

        self.client.post(
            "/budgets",
            data={"year": "۱۴۰۳", "month": "۱", "category_id": str(self.food_category), "amount": "۲۰۰۰۰۰"},
        )
        with self.app.app_context():
            self.assertEqual(finance_db.list_budgets(1403, 1)[0]["budget_amount"], 200_000)

    def test_invalid_budget_category_has_persian_error(self):
        response = self.client.post(
            "/budgets",
            data={"year": "۱۴۰۳", "month": "۰۱", "category_id": "", "amount": "۱۰۰۰۰۰"},
            follow_redirects=True,
        )
        self.assertIn("دسته‌بندی هزینه را انتخاب کنید", response.get_data(as_text=True))

    def test_daily_monthly_yearly_reports_and_report_csv(self):
        self.add_transaction("income", "۱۰۰۰۰۰۰", "۱۴۰۳/۰۱/۰۱", self.income_category, "حقوق")
        self.add_transaction("expense", "۲۵۰۰۰۰", "۱۴۰۳/۰۱/۰۲", self.food_category, "خوراک")
        start, end = month_bounds(1403, 1)
        with self.app.app_context():
            totals = finance_db.get_totals(start, end)
        self.assertEqual(totals, {"income": 1_000_000, "expense": 250_000, "balance": 750_000})
        for mode in ("daily", "monthly", "yearly"):
            response = self.client.get(f"/reports?mode={mode}&year=۱۴۰۳&month=۰۱")
            self.assertEqual(response.status_code, 200)
            self.assertIn("نمودار گزارش درآمد و هزینه", response.get_data(as_text=True))
        response = self.client.get("/reports/export.csv?mode=monthly&year=۱۴۰۳&month=۰۱")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data.startswith(b"\xef\xbb\xbf"))
        self.assertIn("تفکیک هزینه".encode("utf-8"), response.data)

    def test_transaction_csv_export_is_filtered_and_excel_friendly(self):
        self.add_transaction("expense", "۴۵۰۰۰", "۱۴۰۳/۰۱/۰۱", self.food_category, "خرید خوراک")
        self.add_transaction(
            "expense", "۱۰۰۰۰", "۱۴۰۳/۰۱/۰۱", self.food_category,
            '=HYPERLINK("https://example.invalid","لینک")',
        )
        self.add_transaction("income", "۸۰۰۰۰۰", "۱۴۰۳/۰۱/۰۱", self.income_category, "حقوق")
        response = self.client.get("/export.csv?kind=expense")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.data.startswith(b"\xef\xbb\xbf"))
        self.assertIn("خرید خوراک".encode("utf-8"), response.data)
        self.assertIn(b"'=HYPERLINK", response.data)
        self.assertNotIn("حقوق".encode("utf-8"), response.data)

    def test_category_add_edit_safe_delete_and_protected_delete(self):
        response = self.client.post(
            "/categories", data={"name": "آموزش آنلاین", "kind": "expense"},
            follow_redirects=True,
        )
        self.assertIn("آموزش آنلاین", response.get_data(as_text=True))
        with self.app.app_context():
            category_id = next(
                item["id"] for item in finance_db.list_categories("expense")
                if item["name"] == "آموزش آنلاین"
            )
        self.add_transaction("expense", "۱۰۰۰", "۱۴۰۳/۰۱/۰۱", category_id, "کتاب")
        response = self.client.post(
            f"/categories/{category_id}/edit",
            data={"name": "آموزش و کتاب"},
            follow_redirects=True,
        )
        self.assertIn("سوابق قبلی حفظ شدند", response.get_data(as_text=True))
        with self.app.app_context():
            transaction = finance_db.list_transactions()[0]
            self.assertEqual(transaction["category_id"], category_id)
            self.assertEqual(transaction["category_name"], "آموزش و کتاب")

        response = self.client.post(
            f"/categories/{category_id}/delete", follow_redirects=True
        )
        self.assertIn("به تراکنش یا بودجه متصل است", response.get_data(as_text=True))

        self.client.post(
            "/categories", data={"name": "دستهٔ موقت", "kind": "income"}
        )
        with self.app.app_context():
            temporary_id = next(
                item["id"] for item in finance_db.list_categories("income")
                if item["name"] == "دستهٔ موقت"
            )
        response = self.client.post(
            f"/categories/{temporary_id}/delete", follow_redirects=True
        )
        self.assertIn("دسته‌بندی حذف شد", response.get_data(as_text=True))

    def test_seed_data_is_added_once_and_survives_reopen(self):
        seeded_path = Path(self.temp_dir.name) / "sample.sqlite3"
        first = create_app({"TESTING": True, "DATABASE": str(seeded_path)})
        with first.app_context():
            before = len(finance_db.list_transactions())
            self.assertGreater(before, 0)
            today = jalali_today()
            self.assertGreater(len(finance_db.list_budgets(today.year, today.month)), 0)
        second = create_app({"TESTING": True, "DATABASE": str(seeded_path)})
        with second.app_context():
            self.assertEqual(len(finance_db.list_transactions()), before)


if __name__ == "__main__":
    unittest.main()
