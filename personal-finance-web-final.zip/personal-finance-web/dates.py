"""Persian/Jalali date helpers used by the web application."""

from __future__ import annotations

from datetime import date, timedelta
import re

import jdatetime


_DIGITS = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
    "01234567890123456789",
)
_FA_DIGITS = str.maketrans("0123456789", "۰۱۲۳۴۵۶۷۸۹")
MONTH_NAMES = (
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
)


def latin_digits(value: str) -> str:
    return value.translate(_DIGITS)


def persian_digits(value: str | int) -> str:
    return str(value).translate(_FA_DIGITS)


def parse_jalali(value: str) -> date:
    cleaned = latin_digits(value).strip().replace("-", "/").replace(".", "/")
    match = re.fullmatch(r"(\d{4})/(\d{1,2})/(\d{1,2})", cleaned)
    if not match:
        raise ValueError("تاریخ را به شکل سال/ماه/روز وارد کنید؛ مانند ۱۴۰۵/۰۸/۲۶.")
    year, month, day = map(int, match.groups())
    try:
        return jdatetime.date(year, month, day).togregorian()
    except ValueError as exc:
        raise ValueError("تاریخ شمسی واردشده معتبر نیست.") from exc


def to_jalali(value: date) -> str:
    return jdatetime.date.fromgregorian(date=value).strftime("%Y/%m/%d")


def jalali_today() -> jdatetime.date:
    return jdatetime.date.today()


def month_bounds(year: int, month: int) -> tuple[date, date]:
    if not 1 <= month <= 12:
        raise ValueError("ماه باید بین ۱ تا ۱۲ باشد.")
    start = jdatetime.date(year, month, 1).togregorian()
    next_year, next_month = (year + 1, 1) if month == 12 else (year, month + 1)
    end = jdatetime.date(next_year, next_month, 1).togregorian()
    return start, end


def shift_jalali_month(year: int, month: int, offset: int) -> tuple[int, int]:
    month_index = year * 12 + month - 1 + offset
    shifted_year, shifted_month = divmod(month_index, 12)
    return shifted_year, shifted_month + 1


def month_days(year: int, month: int) -> int:
    start, end = month_bounds(year, month)
    return (end - start).days


def jalali_month_label(year: int, month: int) -> str:
    return f"{MONTH_NAMES[month - 1]} {persian_digits(year)}"


def iter_days(start: date, end: date):
    current = start
    while current < end:
        yield current
        current += timedelta(days=1)


def parse_positive_integer(value: str, field_label: str) -> int:
    cleaned = latin_digits(value).replace(",", "").replace("٬", "").replace(" ", "").strip()
    if not cleaned or not cleaned.isdigit():
        raise ValueError(f"{field_label} باید عدد صحیح باشد.")
    result = int(cleaned)
    if result <= 0:
        raise ValueError(f"{field_label} باید بیشتر از صفر باشد.")
    if result > 9_000_000_000_000_000:
        raise ValueError(f"{field_label} بیش از حد مجاز است.")
    return result
