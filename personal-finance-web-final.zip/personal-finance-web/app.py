"""Flask application factory and Persian finance-manager routes."""

from __future__ import annotations

import csv
from datetime import date
import io
import os
import sqlite3

from flask import Flask, Response, flash, redirect, render_template, request, url_for

import db as finance_db
from dates import (
    jalali_month_label,
    jalali_today,
    latin_digits,
    month_bounds,
    parse_jalali,
    parse_positive_integer,
    persian_digits,
    shift_jalali_month,
    to_jalali,
)


def format_money(amount: int | float) -> str:
    return f"{persian_digits(f'{int(round(amount)):,}'.replace(',', '٬'))} تومان"


def _spreadsheet_text(value: str) -> str:
    if value.lstrip(" \t\r\n").startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _current_period() -> tuple[int, int]:
    today = jalali_today()
    return today.year, today.month


def _transaction_form_values() -> tuple[str, int, date, int, str]:
    kind = request.form.get("kind", "").strip()
    if kind not in ("income", "expense"):
        raise ValueError("نوع تراکنش را انتخاب کنید.")
    amount = parse_positive_integer(request.form.get("amount", ""), "مبلغ")
    transaction_date = parse_jalali(request.form.get("transaction_date", ""))
    try:
        category_id = int(latin_digits(request.form.get("category_id", "")))
    except ValueError as exc:
        raise ValueError("دسته‌بندی را انتخاب کنید.") from exc
    description = request.form.get("description", "").strip()
    if len(description) > 240:
        raise ValueError("توضیحات نباید بیشتر از ۲۴۰ نویسه باشد.")
    return kind, amount, transaction_date, category_id, description


def _transaction_filters() -> tuple[dict, dict]:
    filters: dict = {}
    query: dict = {}
    start_value = request.args.get("from", "").strip()
    end_value = request.args.get("to", "").strip()
    kind = request.args.get("kind", "").strip()
    category_text = request.args.get("category", "").strip()
    search = request.args.get("q", "").strip()
    if start_value:
        filters["start_date"] = parse_jalali(start_value).isoformat()
        query["from"] = start_value
    if end_value:
        filters["end_date"] = parse_jalali(end_value).isoformat()
        query["to"] = end_value
    if filters.get("start_date") and filters.get("end_date"):
        if filters["start_date"] > filters["end_date"]:
            raise ValueError("تاریخ شروع نباید پس از تاریخ پایان باشد.")
    if kind in ("income", "expense"):
        filters["kind"] = kind
        query["kind"] = kind
    if category_text:
        try:
            filters["category_id"] = int(latin_digits(category_text))
            query["category"] = category_text
        except ValueError as exc:
            raise ValueError("دسته‌بندی انتخاب‌شده معتبر نیست.") from exc
    if search:
        filters["search"] = search
        query["q"] = search
    return filters, query


def _chart_payload(rows: list[dict], breakdown: list[dict]) -> dict:
    return {
        "labels": [str(row["label"]) for row in rows],
        "income": [int(row["income"]) for row in rows],
        "expenses": [int(row["expense"]) for row in rows],
        "categories": [str(row["category_name"]) for row in breakdown],
        "category_values": [int(row["total"]) for row in breakdown],
    }


def create_app(test_config: dict | None = None) -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("FLASK_SECRET_KEY", "personal-finance-demo-key"),
        DATABASE=os.path.join(app.instance_path, "personal_finance.sqlite3"),
        SEED_DEMO_DATA=True,
        MAX_CONTENT_LENGTH=2 * 1024 * 1024,
    )
    if test_config:
        app.config.update(test_config)

    finance_db.initialize_database(app)
    app.teardown_appcontext(finance_db.close_db)
    app.jinja_env.filters["fa"] = persian_digits
    app.jinja_env.filters["money"] = format_money
    app.jinja_env.filters["jalali"] = lambda value: to_jalali(date.fromisoformat(value))

    @app.get("/")
    def dashboard():
        year, month = _current_period()
        month_start, month_end = month_bounds(year, month)
        totals = finance_db.get_totals()
        monthly_totals = finance_db.get_totals(month_start, month_end)
        recent = finance_db.list_transactions(limit=7)
        budgets = finance_db.list_budgets(year, month)
        category_rows = finance_db.get_expense_breakdown(month_start, month_end)
        month_rows = []
        for offset in range(-5, 1):
            report_year, report_month = shift_jalali_month(year, month, offset)
            summary = finance_db.get_month_summary(report_year, report_month)
            month_rows.append(
                {
                    "label": jalali_month_label(report_year, report_month),
                    "income": summary["income"],
                    "expense": summary["expense"],
                }
            )
        return render_template(
            "dashboard.html",
            title="نمای کلی",
            year=year,
            month=month,
            month_label=jalali_month_label(year, month),
            today_label=persian_digits(jalali_today().strftime("%Y/%m/%d")),
            totals=totals,
            monthly_totals=monthly_totals,
            recent=recent,
            budgets=budgets,
            category_rows=category_rows,
            chart_data=_chart_payload(month_rows, category_rows),
        )

    @app.get("/transactions")
    def transactions():
        try:
            filters, active_query = _transaction_filters()
        except ValueError as exc:
            flash(str(exc), "error")
            filters, active_query = {}, {}
        return render_template(
            "transactions.html",
            title="تراکنش‌ها",
            transactions=finance_db.list_transactions(**filters),
            categories=finance_db.list_categories(),
            filter_values={
                "from": request.args.get("from", ""),
                "to": request.args.get("to", ""),
                "kind": request.args.get("kind", ""),
                "category": request.args.get("category", ""),
                "q": request.args.get("q", ""),
            },
            export_query=active_query,
            today=persian_digits(jalali_today().strftime("%Y/%m/%d")),
        )

    @app.post("/transactions")
    def add_transaction():
        try:
            finance_db.add_transaction(*_transaction_form_values())
            flash("تراکنش با موفقیت ثبت شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("transactions"))

    @app.post("/transactions/<int:transaction_id>/edit")
    def edit_transaction(transaction_id: int):
        try:
            finance_db.update_transaction(
                transaction_id, *_transaction_form_values()
            )
            flash("تراکنش ویرایش شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("transactions"))

    @app.post("/transactions/<int:transaction_id>/delete")
    def remove_transaction(transaction_id: int):
        try:
            finance_db.delete_transaction(transaction_id)
            flash("تراکنش حذف شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("transactions"))

    @app.get("/export.csv")
    def export_csv():
        try:
            filters, _active_query = _transaction_filters()
            rows = finance_db.list_transactions(**filters)
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("transactions"))
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(("شناسه", "نوع", "مبلغ (تومان)", "تاریخ شمسی", "دسته‌بندی", "توضیحات"))
        for row in rows:
            writer.writerow(
                (
                    row["id"],
                    "درآمد" if row["kind"] == "income" else "هزینه",
                    row["amount"],
                    row["jalali_date"],
                    _spreadsheet_text(row["category_name"]),
                    _spreadsheet_text(row["description"]),
                )
            )
        response = Response("\ufeff" + output.getvalue(), content_type="text/csv; charset=utf-8")
        response.headers["Content-Disposition"] = "attachment; filename=gozaresh-mali.csv"
        return response

    @app.get("/budgets")
    def budgets():
        current_year, current_month = _current_period()
        try:
            year = parse_positive_integer(request.args.get("year", str(current_year)), "سال")
            month = parse_positive_integer(request.args.get("month", str(current_month)), "ماه")
            if not 1200 <= year <= 1600 or not 1 <= month <= 12:
                raise ValueError("سال یا ماه شمسی واردشده معتبر نیست.")
        except ValueError as exc:
            flash(str(exc), "error")
            year, month = current_year, current_month
        budget_rows = finance_db.list_budgets(year, month)
        return render_template(
            "budgets.html",
            title="بودجهٔ ماهانه",
            year=year,
            month=month,
            month_label=jalali_month_label(year, month),
            categories=finance_db.list_categories("expense"),
            budgets=budget_rows,
            total_budget=sum(item["budget_amount"] for item in budget_rows),
            total_used=sum(item["used_amount"] for item in budget_rows),
        )

    @app.post("/budgets")
    def save_budget():
        try:
            year = parse_positive_integer(request.form.get("year", ""), "سال")
            month = parse_positive_integer(request.form.get("month", ""), "ماه")
            try:
                category_id = int(latin_digits(request.form.get("category_id", "")))
            except ValueError as exc:
                raise ValueError("دسته‌بندی هزینه را انتخاب کنید.") from exc
            amount = parse_positive_integer(request.form.get("amount", ""), "بودجه")
            if not 1200 <= year <= 1600 or not 1 <= month <= 12:
                raise ValueError("سال یا ماه شمسی واردشده معتبر نیست.")
            finance_db.upsert_budget(year, month, category_id, amount)
            flash("بودجه برای این ماه ذخیره شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
            year, month = _current_period()
        return redirect(url_for("budgets", year=persian_digits(year), month=persian_digits(month)))

    @app.post("/budgets/<int:budget_id>/delete")
    def remove_budget(budget_id: int):
        try:
            finance_db.delete_budget(budget_id)
            flash("بودجه حذف شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        year = request.form.get("year", str(_current_period()[0]))
        month = request.form.get("month", str(_current_period()[1]))
        return redirect(url_for("budgets", year=year, month=month))

    @app.get("/reports")
    def reports():
        current_year, current_month = _current_period()
        mode = request.args.get("mode", "monthly")
        if mode not in ("daily", "monthly", "yearly"):
            mode = "monthly"
        try:
            year = parse_positive_integer(request.args.get("year", str(current_year)), "سال")
            month = parse_positive_integer(request.args.get("month", str(current_month)), "ماه")
            if not 1200 <= year <= 1600 or not 1 <= month <= 12:
                raise ValueError("سال یا ماه شمسی واردشده معتبر نیست.")
        except ValueError as exc:
            flash(str(exc), "error")
            year, month = current_year, current_month

        if mode == "daily":
            rows = finance_db.get_daily_report(year, month)
            start, end = month_bounds(year, month)
            heading = f"گزارش روزانهٔ {jalali_month_label(year, month)}"
            breakdown_title = "هزینه‌های همین ماه"
        elif mode == "yearly":
            rows = finance_db.get_yearly_report(year)
            start, end = month_bounds(year, 1)[0], month_bounds(year + 1, 1)[0]
            heading = f"مقایسهٔ سالانه تا {persian_digits(year)}"
            breakdown_title = f"هزینه‌های سال {persian_digits(year)}"
        else:
            rows = finance_db.get_monthly_report(year)
            start, end = month_bounds(year, 1)[0], month_bounds(year + 1, 1)[0]
            heading = f"گزارش ماهانهٔ سال {persian_digits(year)}"
            breakdown_title = f"هزینه‌های سال {persian_digits(year)}"
        totals = finance_db.get_totals(start, end)
        breakdown = finance_db.get_expense_breakdown(start, end)
        return render_template(
            "reports.html",
            title="گزارش‌ها",
            mode=mode,
            year=year,
            month=month,
            heading=heading,
            breakdown_title=breakdown_title,
            totals=totals,
            rows=rows,
            breakdown=breakdown,
            chart_data=_chart_payload(rows, breakdown),
        )

    @app.get("/reports/export.csv")
    def export_report_csv():
        current_year, current_month = _current_period()
        mode = request.args.get("mode", "monthly")
        if mode not in ("daily", "monthly", "yearly"):
            mode = "monthly"
        try:
            year = parse_positive_integer(request.args.get("year", str(current_year)), "سال")
            month = parse_positive_integer(request.args.get("month", str(current_month)), "ماه")
            if not 1200 <= year <= 1600 or not 1 <= month <= 12:
                raise ValueError("سال یا ماه شمسی واردشده معتبر نیست.")
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("reports"))

        if mode == "daily":
            rows = finance_db.get_daily_report(year, month)
            report_name = f"روزانهٔ {jalali_month_label(year, month)}"
            start, end = month_bounds(year, month)
        elif mode == "yearly":
            rows = finance_db.get_yearly_report(year)
            report_name = f"سالانه تا {persian_digits(year)}"
            start, end = month_bounds(year, 1)[0], month_bounds(year + 1, 1)[0]
        else:
            rows = finance_db.get_monthly_report(year)
            report_name = f"ماهانهٔ سال {persian_digits(year)}"
            start, end = month_bounds(year, 1)[0], month_bounds(year + 1, 1)[0]
        breakdown = finance_db.get_expense_breakdown(start, end)
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(("نوع گزارش", "بازه", "درآمد (تومان)", "هزینه (تومان)", "تراز (تومان)"))
        for row in rows:
            writer.writerow(
                (
                    report_name,
                    row["label"],
                    row["income"],
                    row["expense"],
                    row["balance"],
                )
            )
        writer.writerow(())
        writer.writerow(("تفکیک هزینه", "دسته‌بندی", "مبلغ (تومان)"))
        for row in breakdown:
            writer.writerow(("هزینه", _spreadsheet_text(row["category_name"]), row["total"]))
        response = Response("\ufeff" + output.getvalue(), content_type="text/csv; charset=utf-8")
        response.headers["Content-Disposition"] = "attachment; filename=gozaresh-mali.csv"
        return response

    @app.route("/categories", methods=("GET", "POST"))
    def categories():
        if request.method == "POST":
            try:
                finance_db.add_category(
                    request.form.get("name", ""),
                    request.form.get("kind", ""),
                )
                flash("دسته‌بندی جدید ثبت شد.", "success")
            except ValueError as exc:
                flash(str(exc), "error")
            return redirect(url_for("categories"))
        return render_template(
            "categories.html",
            title="دسته‌بندی‌ها",
            income_categories=finance_db.list_categories("income"),
            expense_categories=finance_db.list_categories("expense"),
        )

    @app.post("/categories/<int:category_id>/edit")
    def edit_category(category_id: int):
        try:
            finance_db.update_category(category_id, request.form.get("name", ""))
            flash("نام دسته‌بندی ویرایش شد؛ سوابق قبلی حفظ شدند.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("categories"))

    @app.post("/categories/<int:category_id>/delete")
    def remove_category(category_id: int):
        try:
            finance_db.delete_category(category_id)
            flash("دسته‌بندی حذف شد.", "success")
        except ValueError as exc:
            flash(str(exc), "error")
        return redirect(url_for("categories"))

    @app.errorhandler(404)
    def not_found(_error):
        return render_template("404.html", title="صفحه پیدا نشد"), 404

    @app.errorhandler(sqlite3.Error)
    def database_error(error):
        app.logger.exception("SQLite error", exc_info=error)
        from flask import g

        connection = g.get("db")
        if connection is not None:
            connection.rollback()
        flash("خطایی در ذخیره‌سازی اطلاعات رخ داد. دوباره تلاش کنید.", "error")
        return redirect(url_for("dashboard"))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", "8000")),
        debug=False,
    )
