(() => {
  "use strict";

  const svgNamespace = "http://www.w3.org/2000/svg";
  const incomeColor = "#49a986";
  const expenseColor = "#e17b6d";
  const numberFormat = new Intl.NumberFormat("fa-IR");

  function svgElement(tag, attributes = {}, text = "") {
    const element = document.createElementNS(svgNamespace, tag);
    Object.entries(attributes).forEach(([key, value]) => element.setAttribute(key, value));
    if (text !== "") element.textContent = text;
    return element;
  }

  function drawFinancialChart(data) {
    const svg = document.getElementById("income-expense-chart");
    if (!svg) return;
    svg.replaceChildren();
    const labels = Array.isArray(data.labels) ? data.labels : [];
    const income = Array.isArray(data.income) ? data.income : [];
    const expenses = Array.isArray(data.expenses) ? data.expenses : [];
    const width = 820;
    const height = 300;
    const margin = { top: 15, right: 22, bottom: 48, left: 72 };
    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    svg.setAttribute("preserveAspectRatio", "xMidYMid meet");

    if (!labels.length) {
      svg.appendChild(svgElement("text", {
        x: width / 2, y: height / 2, "text-anchor": "middle", class: "chart-empty",
      }, "داده‌ای برای نمایش وجود ندارد"));
      return;
    }

    const maxValue = Math.max(1, ...income, ...expenses);
    const scaleTop = maxValue * 1.12;
    const groupWidth = plotWidth / labels.length;
    const barWidth = Math.max(3, Math.min(18, groupWidth * 0.28));
    const tickCount = 4;

    for (let tick = 0; tick <= tickCount; tick += 1) {
      const fraction = tick / tickCount;
      const y = margin.top + plotHeight * fraction;
      const value = Math.round(scaleTop * (1 - fraction));
      svg.appendChild(svgElement("line", {
        x1: margin.left, y1: y, x2: width - margin.right, y2: y, class: "chart-grid-line",
      }));
      svg.appendChild(svgElement("text", {
        x: margin.left - 9, y: y + 4, "text-anchor": "end", class: "chart-axis-label",
      }, numberFormat.format(value)));
    }

    labels.forEach((label, index) => {
      const center = margin.left + groupWidth * (index + 0.5);
      const incomeHeight = Math.max(0, (income[index] || 0) / scaleTop * plotHeight);
      const expenseHeight = Math.max(0, (expenses[index] || 0) / scaleTop * plotHeight);
      svg.appendChild(svgElement("rect", {
        x: center - barWidth - 2, y: margin.top + plotHeight - incomeHeight,
        width: barWidth, height: Math.max(0, incomeHeight), rx: 3, class: "chart-bar-income",
      }));
      svg.appendChild(svgElement("rect", {
        x: center + 2, y: margin.top + plotHeight - expenseHeight,
        width: barWidth, height: Math.max(0, expenseHeight), rx: 3, class: "chart-bar-expense",
      }));
      const labelElement = svgElement("text", {
        x: center, y: height - 15, "text-anchor": "middle", class: "chart-x-label",
      }, label);
      if (labels.length > 16) labelElement.setAttribute("font-size", "8");
      svg.appendChild(labelElement);
    });
  }

  function drawBreakdown(data) {
    const container = document.querySelector("[data-breakdown]");
    if (!container) return;
    container.replaceChildren();
    const labels = Array.isArray(data.categories) ? data.categories : [];
    const values = Array.isArray(data.category_values) ? data.category_values : [];
    const maxValue = Math.max(1, ...values);
    labels.forEach((label, index) => {
      const row = document.createElement("div");
      row.className = "breakdown-row";
      const name = document.createElement("span");
      name.className = "breakdown-name";
      name.textContent = label;
      const track = document.createElement("span");
      track.className = "breakdown-track";
      const fill = document.createElement("span");
      fill.className = "breakdown-fill";
      fill.style.width = `${Math.max(4, (values[index] / maxValue) * 100)}%`;
      track.appendChild(fill);
      const amount = document.createElement("span");
      amount.className = "breakdown-value";
      amount.textContent = `${numberFormat.format(values[index] || 0)} تومان`;
      row.append(name, track, amount);
      container.appendChild(row);
    });
  }

  function loadCharts() {
    const dataElement = document.getElementById("chart-data");
    if (!dataElement) return;
    try {
      const data = JSON.parse(dataElement.textContent);
      drawFinancialChart(data);
      drawBreakdown(data);
    } catch (_error) {
      const chart = document.getElementById("income-expense-chart");
      if (chart) {
        chart.replaceChildren(svgElement("text", {
          x: 410, y: 150, "text-anchor": "middle", class: "chart-empty",
        }, "نمودار بارگذاری نشد"));
      }
    }
  }

  window.toggleSidebar = function toggleSidebar() {
    const sidebar = document.getElementById("sidebar");
    const scrim = document.getElementById("sidebar-scrim");
    if (!sidebar || !scrim) return;
    sidebar.classList.toggle("open");
    scrim.classList.toggle("visible");
  };

  window.openTransactionDialog = function openTransactionDialog(event) {
    if (event) event.preventDefault();
    const dialog = document.getElementById("transaction-modal");
    const form = document.getElementById("transaction-form");
    if (!dialog || !form) return;
    form.reset();
    form.action = "/transactions";
    document.getElementById("transaction-modal-title").textContent = "تراکنش جدید";
    updateCategoryOptions();
    if (!dialog.open) dialog.showModal();
  };

  window.closeTransactionDialog = function closeTransactionDialog() {
    const dialog = document.getElementById("transaction-modal");
    if (dialog && dialog.open) dialog.close();
  };

  window.openEditTransaction = function openEditTransaction(button) {
    const dialog = document.getElementById("transaction-modal");
    const form = document.getElementById("transaction-form");
    if (!dialog || !form) return;
    form.reset();
    form.action = `/transactions/${encodeURIComponent(button.dataset.id)}/edit`;
    document.getElementById("transaction-modal-title").textContent = "ویرایش تراکنش";
    document.getElementById("transaction-kind").value = button.dataset.kind;
    form.elements.amount.value = button.dataset.amount;
    document.getElementById("transaction-date").value = button.dataset.date;
    form.elements.description.value = button.dataset.description || "";
    updateCategoryOptions(button.dataset.category);
    dialog.showModal();
  };

  function updateCategoryOptions(selectedValue) {
    const kindSelect = document.getElementById("transaction-kind");
    const categorySelect = document.getElementById("transaction-category");
    if (!kindSelect || !categorySelect) return;
    const options = Array.from(categorySelect.options);
    let firstAvailable = "";
    options.forEach((option) => {
      option.hidden = option.dataset.kind !== kindSelect.value;
      option.disabled = option.hidden;
      if (!option.disabled && !firstAvailable) firstAvailable = option.value;
    });
    const selectedIsAvailable = options.some(
      (option) => option.value === String(selectedValue || "") && !option.disabled,
    );
    categorySelect.value = selectedIsAvailable ? selectedValue : firstAvailable;
  }

  window.editBudget = function editBudget(button) {
    const categorySelect = document.getElementById("budget-category");
    const amountInput = document.getElementById("budget-amount");
    if (!categorySelect || !amountInput) return;
    categorySelect.value = button.dataset.category;
    amountInput.value = button.dataset.amount;
    amountInput.focus();
    document.getElementById("budget-form").scrollIntoView({ behavior: "smooth", block: "center" });
  };

  window.openEditCategory = function openEditCategory(button) {
    const dialog = document.getElementById("category-modal");
    const form = document.getElementById("category-form");
    const nameInput = document.getElementById("category-name");
    if (!dialog || !form || !nameInput) return;
    form.action = button.dataset.url;
    nameInput.value = button.dataset.name || "";
    dialog.showModal();
    nameInput.focus();
    nameInput.select();
  };

  window.closeCategoryDialog = function closeCategoryDialog() {
    const dialog = document.getElementById("category-modal");
    if (dialog && dialog.open) dialog.close();
  };

  document.addEventListener("DOMContentLoaded", () => {
    loadCharts();
    document.querySelectorAll(".flash").forEach((flash) => {
      window.setTimeout(() => {
        if (flash.isConnected) flash.remove();
      }, 6500);
    });
    const kindSelect = document.getElementById("transaction-kind");
    if (kindSelect) kindSelect.addEventListener("change", () => updateCategoryOptions());
    const transactionDialog = document.getElementById("transaction-modal");
    if (transactionDialog) {
      transactionDialog.addEventListener("click", (event) => {
        if (event.target === transactionDialog) transactionDialog.close();
      });
    }
    const categoryDialog = document.getElementById("category-modal");
    if (categoryDialog) {
      categoryDialog.addEventListener("click", (event) => {
        if (event.target === categoryDialog) categoryDialog.close();
      });
    }
  });
})();
